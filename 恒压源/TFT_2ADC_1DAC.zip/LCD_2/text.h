#ifndef __TEXT_H__
#define __TEXT_H__	 
 #include "stm32f4xx.h"
// SRT ��string����д
#define STR_WIDTH		8		/* �ַ����� */
#define STR_HEIGHT		16		/* �ַ��߶� */

void LCD_ShowChar(uint16_t x,uint16_t y,uint8_t num,uint8_t size,uint8_t mode,uint16_t Color);
void LCD_ShowString(uint16_t x,uint16_t y,const uint8_t *p,uint16_t Color);


#endif
